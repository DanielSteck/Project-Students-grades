# Project-Students-grades
This project was created during the modul Programming languages for Data Science which is part of my Master studies program.
